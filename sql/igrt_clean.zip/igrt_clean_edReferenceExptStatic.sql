CREATE DATABASE  IF NOT EXISTS `igrt_clean` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `igrt_clean`;
-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: igrt_clean
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edReferenceExptStatic`
--

DROP TABLE IF EXISTS `edReferenceExptStatic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `edReferenceExptStatic` (
  `exptId` int NOT NULL,
  `languageId` int NOT NULL,
  `owner` int NOT NULL,
  `description` varchar(8192) CHARACTER SET utf8mb3 DEFAULT NULL,
  `isClassic` tinyint NOT NULL DEFAULT '0',
  `useAutoLogins` tinyint NOT NULL DEFAULT '0',
  `exptSubject` int NOT NULL DEFAULT '1',
  `location` int NOT NULL,
  `country` int NOT NULL DEFAULT '225',
  `noJudges` int NOT NULL DEFAULT '12',
  `extraJ` tinyint NOT NULL DEFAULT '0',
  `extraNP` tinyint NOT NULL DEFAULT '0',
  `extraP` tinyint NOT NULL DEFAULT '0',
  `canClone` tinyint NOT NULL DEFAULT '1',
  `includeRatings` tinyint NOT NULL DEFAULT '1',
  `labelChoice` varchar(256) CHARACTER SET utf8mb3 NOT NULL,
  `useLikert` tinyint NOT NULL DEFAULT '1',
  `noLikert` int NOT NULL DEFAULT '5',
  `instLikert` varchar(2048) CHARACTER SET utf8mb3 DEFAULT NULL,
  `useReasons` tinyint NOT NULL DEFAULT '1',
  `labelReasons` varchar(2048) CHARACTER SET utf8mb3 DEFAULT NULL,
  `useExtraLikert` tinyint NOT NULL DEFAULT '0',
  `noExtraLikert` int NOT NULL DEFAULT '5',
  `instExtraLikert` varchar(2048) CHARACTER SET utf8mb3 DEFAULT NULL,
  `useFinalRating` tinyint NOT NULL DEFAULT '1',
  `labelFinalRating` varchar(1024) CHARACTER SET utf8mb3 NOT NULL,
  `labelChoiceFinalRating` varchar(1024) CHARACTER SET utf8mb3 NOT NULL,
  `useReasonFinalRating` int NOT NULL DEFAULT '1',
  `labelReasonFinalRating` varchar(1024) CHARACTER SET utf8mb3 NOT NULL,
  `noDays` int NOT NULL DEFAULT '1',
  `noSessions` int NOT NULL DEFAULT '1',
  `useConsent` tinyint NOT NULL DEFAULT '0',
  `useStep1Recruit` tinyint NOT NULL DEFAULT '0',
  `useStep2Recruit` tinyint NOT NULL DEFAULT '0',
  `useStep4Recruit` tinyint NOT NULL DEFAULT '0',
  `needReviewLO` tinyint NOT NULL DEFAULT '0',
  `reviewedByLO` tinyint NOT NULL DEFAULT '0',
  `useFinalLikert` tinyint NOT NULL DEFAULT '0',
  `noFinalLikert` tinyint NOT NULL DEFAULT '5',
  `instFinalLikert` text CHARACTER SET utf8mb3 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edReferenceExptStatic`
--

LOCK TABLES `edReferenceExptStatic` WRITE;
/*!40000 ALTER TABLE `edReferenceExptStatic` DISABLE KEYS */;
INSERT INTO `edReferenceExptStatic` VALUES (18,15,28,'Religion',0,1,2,8,225,12,0,0,0,1,1,'This respondent is NOT pretending',1,4,'Please rate your confidence in your judgement',1,'Please explain briefly the reasons for your judgement',0,5,'',1,'Taking all responses into account, please indicate which respondent is NOT pretending','This respondent is NOT pretending',1,'Please explain the overall reasons for your judgement',1,2,1,0,0,0,0,0,0,5,''),(27,18,28,'Helsinki Step1 Practise',0,1,1,11,225,24,0,0,0,1,1,'This person is the pretenderh',1,4,'Please rate your confidenceh',1,'Please give your reason for your choiceh',0,5,'',1,'Please supply some final informationh','This person is the pretenderh',1,'Please give your overall reasoning for your choiceh',1,2,1,0,0,0,0,0,0,5,''),(29,14,28,'Rotterdam Field Trip',0,1,2,4,150,12,0,0,0,1,1,'Deze deelnemer doet alsof',1,4,'Geef je mate van zekerheid aan',1,'Geef alsjeblieft een onderbouwing voor je keuze ',0,5,'',1,'Geef alsjeblieft wat afsluitende informatie ','Deze deelnemer doet alsof',1,'Licht alsjeblieft de overkoepelende gedachtegang achter je keuze toe ',3,2,0,0,0,0,0,0,1,4,'Geef je mate van zekerheid aan'),(36,57,187,'label test',0,1,1,13,199,9,0,0,0,1,1,'Este es el Fingidor',1,4,'Califica el nivel de seguridad que tienes',1,'Razona tu respuesta',0,5,'',1,'Da mÃ¡s informaciÃ³n sobre tu respuesta','',1,'Da una razÃ³n final sobre el por quÃ© de tu elecciÃ³n',1,1,0,0,0,0,0,0,1,4,'Please rate your overall confidence'),(44,47,187,'WRO_20130318_sexuality',0,1,1,13,171,20,0,0,0,1,1,'Ta osoba jest osobÄ… udajÄ…cÄ…',1,4,'ProszÄ™ oceÅ„ swojÄ… pewnoÅ›Ä‡',1,'ProszÄ™ podaÄ‡ powÃ³d swojego wyboru',0,5,'',1,'ProszÄ™ podaÄ‡ koÅ„cowÄ… informacjÄ™','Ta osoba jest osobÄ… udajÄ…cÄ…',1,'ProszÄ™ podsumowaÄ‡ powÃ³d swojego wyboru',1,1,0,0,0,0,0,0,1,4,'ProszÄ™ oceniÄ‡ ogÃ³lny stopieÅ„ pewnoÅ›ci');
/*!40000 ALTER TABLE `edReferenceExptStatic` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-01 10:48:15
