CREATE DATABASE  IF NOT EXISTS `igrt_clean` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `igrt_clean`;
-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: igrt_clean
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edContentDefs_refactor`
--

DROP TABLE IF EXISTS `edContentDefs_refactor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `edContentDefs_refactor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `exptId` int NOT NULL,
  `description` text CHARACTER SET utf8mb3 NOT NULL,
  `labelChoice` text CHARACTER SET utf8mb3 NOT NULL,
  `instLikert` text CHARACTER SET utf8mb3 NOT NULL,
  `labelReasons` text CHARACTER SET utf8mb3 NOT NULL,
  `instExtraLikert` text CHARACTER SET utf8mb3 NOT NULL,
  `labelFinalRating` text CHARACTER SET utf8mb3 NOT NULL,
  `labelChoiceFinalRating` text CHARACTER SET utf8mb3 NOT NULL,
  `labelReasonFinalRating` text CHARACTER SET utf8mb3 NOT NULL,
  `instFinalLikert` text CHARACTER SET utf8mb3 NOT NULL,
  `reasonGuidance` text CHARACTER SET utf8mb3 NOT NULL,
  `reasonGuidanceF` text CHARACTER SET utf8mb3 NOT NULL,
  `labelRating` text CHARACTER SET utf8mb3 NOT NULL,
  `s1CategoryLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s1IntentionLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s1AlignmentNoneLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s1AlignmentPartlyLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s1AlignmentMostlyLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s1AlignmentCompletelyLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s1AlignmentLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s4IntentionLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s4AlignmentNoneLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s4AlignmentPartlyLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s4AlignmentMostlyLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s4AlignmentCompletelyLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s4AlignmentLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s4QCategoryLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s2PAlignmentLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s2PYesLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s2PNoLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s2ContinueLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s2CorrectedAnswerLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `iS2NPAlignmentLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `iS2NPYesLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `iS2NPNoLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `iS2ContinueLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `iS2CorrectedAnswerLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `jTab` text CHARACTER SET utf8mb3 NOT NULL,
  `jTabUnconnected` text CHARACTER SET utf8mb3 NOT NULL,
  `jTabWaiting` text CHARACTER SET utf8mb3 NOT NULL,
  `jTabActive` text CHARACTER SET utf8mb3 NOT NULL,
  `jTabRating` text CHARACTER SET utf8mb3 NOT NULL,
  `jTabDone` text CHARACTER SET utf8mb3 NOT NULL,
  `jWaitingToStart` text CHARACTER SET utf8mb3 NOT NULL,
  `jPleaseAsk` text CHARACTER SET utf8mb3 NOT NULL,
  `jAskButton` text CHARACTER SET utf8mb3 NOT NULL,
  `jWaitingForReplies` text CHARACTER SET utf8mb3 NOT NULL,
  `jHistoryTitle` text CHARACTER SET utf8mb3 NOT NULL,
  `jRatingTitle` text CHARACTER SET utf8mb3 NOT NULL,
  `jFinalRatingTitle` text CHARACTER SET utf8mb3 NOT NULL,
  `jRatingYourQuestion` text CHARACTER SET utf8mb3 NOT NULL,
  `jRatingQ` text CHARACTER SET utf8mb3 NOT NULL,
  `jRatingR1` text CHARACTER SET utf8mb3 NOT NULL,
  `jRatingR2` text CHARACTER SET utf8mb3 NOT NULL,
  `jAskAnotherB` text CHARACTER SET utf8mb3 NOT NULL,
  `jNoMoreB` text CHARACTER SET utf8mb3 NOT NULL,
  `jSaveFinalB` text CHARACTER SET utf8mb3 NOT NULL,
  `jFinalMsg` text CHARACTER SET utf8mb3 NOT NULL,
  `jConfirmHead` text CHARACTER SET utf8mb3 NOT NULL,
  `jConfirmBody` text CHARACTER SET utf8mb3 NOT NULL,
  `jConfirmOK` text CHARACTER SET utf8mb3 NOT NULL,
  `jConfirmCancel` text CHARACTER SET utf8mb3 NOT NULL,
  `npTab` text CHARACTER SET utf8mb3 NOT NULL,
  `pTab` text CHARACTER SET utf8mb3 NOT NULL,
  `rTabInactive` text CHARACTER SET utf8mb3 NOT NULL,
  `rTabActive` text CHARACTER SET utf8mb3 NOT NULL,
  `rTabWaiting` text CHARACTER SET utf8mb3 NOT NULL,
  `rTabDone` text CHARACTER SET utf8mb3 NOT NULL,
  `rWaitFirst` text CHARACTER SET utf8mb3 NOT NULL,
  `rWaitNext` text CHARACTER SET utf8mb3 NOT NULL,
  `rHistoryTitle` text CHARACTER SET utf8mb3 NOT NULL,
  `rCurrentQ` text CHARACTER SET utf8mb3 NOT NULL,
  `rInstruction` text CHARACTER SET utf8mb3 NOT NULL,
  `rSendB` text CHARACTER SET utf8mb3 NOT NULL,
  `rGuidanceHeader` text CHARACTER SET utf8mb3 NOT NULL,
  `rYourAnswer` text CHARACTER SET utf8mb3 NOT NULL,
  `rFinalMsg` text CHARACTER SET utf8mb3 NOT NULL,
  `npGuidance` text CHARACTER SET utf8mb3 NOT NULL,
  `pGuidance` text CHARACTER SET utf8mb3 NOT NULL,
  `step2_startMsg` text CHARACTER SET utf8mb3 NOT NULL,
  `step2_startBLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `step2_finalMsg` text CHARACTER SET utf8mb3 NOT NULL,
  `step2_closedMsg` text CHARACTER SET utf8mb3 NOT NULL,
  `step2_replyMsg` text CHARACTER SET utf8mb3 NOT NULL,
  `step2_endBLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `step4_judgeNumberMsg` text CHARACTER SET utf8mb3 NOT NULL,
  `step4_startMsg` text CHARACTER SET utf8mb3 NOT NULL,
  `step4_startBLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `step4_closedMsg` text CHARACTER SET utf8mb3 NOT NULL,
  `step4_finalMsg` text CHARACTER SET utf8mb3 NOT NULL,
  `step4_nextBLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `step4_reasonMsg` text CHARACTER SET utf8mb3 NOT NULL,
  `step2_invertedStartMsg` text CHARACTER SET utf8mb3 NOT NULL,
  `step2_invertedStartBLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `step2_invertedFinalMsg` text CHARACTER SET utf8mb3 NOT NULL,
  `step2_invertedClosedMsg` text CHARACTER SET utf8mb3 NOT NULL,
  `step2_invertedReplyMsg` text CHARACTER SET utf8mb3 NOT NULL,
  `step2_invertedEndBLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `evenS1Label` text CHARACTER SET utf8mb3 NOT NULL,
  `oddS1Label` text CHARACTER SET utf8mb3 NOT NULL,
  `step2_sendBLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `step2_invertedSendBLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `step4_reasonGuidance` text CHARACTER SET utf8mb3 NOT NULL,
  `step4_endBLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `step2_ReplyLimitGuidance` text CHARACTER SET utf8mb3 NOT NULL,
  `istep2_ReplyLimitGuidance` text CHARACTER SET utf8mb3 NOT NULL,
  `step4IntentionLimitGuidance` text CHARACTER SET utf8mb3 NOT NULL,
  `s1AlignmentExtraLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s1correctFB` text CHARACTER SET utf8mb3 NOT NULL,
  `s1incorrectFB` text CHARACTER SET utf8mb3 NOT NULL,
  `s1runningScoreLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s1runningScoreDividerLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s1LoseFeedbackLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s1WinFeedbackLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s1IntentionMinLabel` text CHARACTER SET utf8mb3 NOT NULL,
  `s1QuestionMinLabel` text CHARACTER SET utf8mb3 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edContentDefs_refactor`
--

LOCK TABLES `edContentDefs_refactor` WRITE;
/*!40000 ALTER TABLE `edContentDefs_refactor` DISABLE KEYS */;
INSERT INTO `edContentDefs_refactor` VALUES (137,1,'Cardiff Alignment Tests','This person is the non-pretender (i.e. a member of the same group as you)','Please rate your certainty','Please give your reasons for your choice','','','This person is the non-pretender (i.e. a member of the same group as you)','Please give you overall reasons for your choice. (min. 64 characters)','Please rate your overall certainty','You must provide a reason with a minimum of 2 characters','Your reason must have a minimum of 64 characters','Please choose the non- pretender, and give some reasons for doing so','Please indicate what was most helpful in reaching your decision.','Why are you asking this question?','not at all','slightly','mostly','completely','Is this a response you would expect from a member of your group?','Please describe why you think the interrogator asked this question','not all all','partly','mostly','completely','Is this the answer you\'d expect from you group','Please indicate what was most helpful in making your judgement','Would this have been the answer you would have given had you not been trying to follow the instructions? ','Yes','No','Continue','Please provide the answer you would have provided had you not been trying to follow the instructions','Would this have been the answer you would have given had you not been trying to follow the instructions? ','Yes','No','Continue','Please provide the answer you would have provided had you not been trying to follow the instructions','Judge','unconnected','waiting','active','judging','complete','Waiting for the experiment to start','Please ask a question','Send question','Please wait for replies','Previous questions/answers','Please make some ratings','Please make some final judgements.','Please ask a question','Question ','Response 1:','Response 2:','Ask another question','No more questions','Save my final ratings','Thank you for being a judge. Please continue to answer questions to other judges as appropriate.','Are you sure?','Are you sure you want to finish asking questions? You will be prompted for some final ratings','Finish','Cancel','Non-pretender','Pretender','inactive','active','waiting','done','Please wait for the first message','Please wait for the next message','Previous questions/answers','Question','Please answer the question and press the \'send\' button','Send','Guidance','Your reply','The judge has finished asking you questions. Please continue to monitor the other tabs and respond accordingly','In this role you are answering truthfully','In this role you are pretending, and should try to understand the judge\'s motives for asking the question, and pretend accordingly.','','Start','Click \'go to survey\' to perform the final survey','This Step2 is no longer open to participants','Enter your answer. Remember: you are pretending in this experiment.','Go to survey','','','Start','This step4 experiment is closed.','You have finished judging. Please click on \'go to survey\' to undertake the final phase of this experiment.','Done next transcript','','','Start','Click \'go to survey\' to perform the final survey.','This inverted Step2 is closed.','Enter your answer. Remember, you are answering naturally in this experiment.','Go to survey','Lecturer','Student','Send','Send','Please give your reasons for your choice. Please try to be as thorough and descriptive as you can. There is a minimum character limit of 256 characters to ensure good quality reasoning.','Go to survey','','','Your answer should contain a minimum of 4 characters','','','','','','','','','');
/*!40000 ALTER TABLE `edContentDefs_refactor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-01 10:47:16
