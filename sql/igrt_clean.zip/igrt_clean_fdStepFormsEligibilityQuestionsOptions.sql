CREATE DATABASE  IF NOT EXISTS `igrt_clean` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `igrt_clean`;
-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: igrt_clean
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fdStepFormsEligibilityQuestionsOptions`
--

DROP TABLE IF EXISTS `fdStepFormsEligibilityQuestionsOptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fdStepFormsEligibilityQuestionsOptions` (
  `exptId` int DEFAULT NULL,
  `formType` int DEFAULT NULL,
  `label` text CHARACTER SET latin1,
  `displayOrder` int DEFAULT NULL,
  `isEligibleResponse` int DEFAULT '0',
  `jType` int DEFAULT '2' COMMENT '0 = even\n1 = odd\n2 = not a jType',
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=74559 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fdStepFormsEligibilityQuestionsOptions`
--

LOCK TABLES `fdStepFormsEligibilityQuestionsOptions` WRITE;
/*!40000 ALTER TABLE `fdStepFormsEligibilityQuestionsOptions` DISABLE KEYS */;
INSERT INTO `fdStepFormsEligibilityQuestionsOptions` VALUES (256,3,'Scottish',0,1,0,1),(256,3,'English',1,1,1,2),(256,3,'Neither of these',2,0,1,3),(256,6,'Scottish',0,1,0,4),(256,6,'English',1,1,1,5),(256,6,'Neither of these',2,0,1,6),(256,10,'Scottish',0,1,0,7),(256,10,'English',1,1,1,8),(256,10,'Neither of these',2,0,1,9),(256,11,'Scottish',0,1,0,10),(256,11,'English',1,1,1,11),(256,11,'Neither of these',2,0,1,12),(256,2,'Scottish',0,1,0,13),(256,2,'English',1,1,1,14),(256,2,'Neither of these',2,0,1,15),(273,2,'first eligibility option',0,0,0,16),(273,6,'I am gay',0,1,0,17),(273,6,'I am straight',1,1,1,18),(273,6,'I am bisexual',2,0,0,19),(273,12,'I am gay',0,1,0,20),(273,12,'I am straight',1,1,1,21),(273,12,'I am bisexual',2,0,0,22),(273,3,'first eligibility option',0,0,0,23),(276,13,'first eligibility option',0,0,0,24),(273,7,'I am gay',0,1,0,25),(273,7,'I am straight',1,1,1,26),(276,5,'first eligibility option',0,0,0,27),(256,8,'first eligibility option',0,0,0,28),(256,12,'first eligibility option',0,0,0,29),(256,13,'first eligibility option',0,0,0,30),(256,7,'first eligibility option',0,0,0,31),(276,6,'I am straight',0,1,0,32),(276,6,'I am gay',1,0,0,33),(276,7,'first eligibility option',0,0,0,34),(275,6,'Jestem hetero',0,1,0,35),(275,6,'Jestem gejem',1,0,0,36),(275,7,'first eligibility option',0,0,0,37),(275,13,'first eligibility option',0,0,0,38),(275,12,'Jestem gejem',0,1,0,39),(275,12,'Jestem hetero',1,0,0,40),(279,6,'female',0,1,1,41),(279,6,'male',1,1,0,42),(279,7,'first eligibility option',0,0,0,43),(280,7,'first eligibility option',0,0,0,44),(276,0,'first eligibility option',0,0,0,45),(279,0,'first eligibility option',0,0,0,46),(2809,6,'first eligibility option',0,0,0,47),(280,0,'first eligibility option',0,0,0,48),(278,10,'first eligibility option',0,0,0,49),(278,11,'first eligibility option',0,0,0,50),(282,10,'first eligibility option',0,0,0,51),(281,10,'first eligibility option',0,0,0,52),(276,10,'first eligibility option',0,0,0,53),(281,11,'first eligibility option',0,0,0,54),(282,11,'first eligibility option',0,0,0,55),(282,6,'first eligibility option',0,0,0,56),(282,7,'first eligibility option',0,0,0,57),(286,7,'first eligibility option',0,0,0,58),(286,0,'first eligibility option',0,0,0,59),(281,6,'first eligibility option',0,0,0,60),(280,6,'female',0,1,1,61),(280,6,'male',1,1,0,62),(285,6,'female',0,1,1,63),(285,6,'male',1,1,0,64),(285,12,'female',0,1,0,65),(285,12,'male',1,1,0,66),(285,7,'first eligibility option',0,0,0,67),(276,12,'I am gay',0,1,0,68),(276,12,'I am straight',1,0,0,69),(289,6,'I am Scottish',0,1,0,70),(289,6,'I am English',1,1,1,71),(285,13,'first eligibility option',0,0,0,72),(289,7,'first eligibility option',0,0,0,73),(288,6,'female',0,1,1,74),(288,6,'male',1,1,0,75),(284,6,'female',0,1,1,76),(284,6,'male',1,1,0,77),(275,10,'Jestem hetero',0,0,0,78),(275,10,'Jestem gejem',1,1,0,79),(284,0,'first eligibility option',0,0,0,80),(275,11,'first eligibility option',0,0,0,81),(285,11,'first eligibility option',0,0,0,82),(291,11,'first eligibility option',0,0,0,83),(286,6,'female',0,1,0,84),(286,6,'male',1,0,1,85),(260,11,'first eligibility option',0,0,0,86),(288,11,'first eligibility option',0,0,0,87),(292,11,'first eligibility option',0,0,0,88),(293,10,'first eligibility option',0,0,0,89),(293,11,'first eligibility option',0,0,0,90),(288,12,'female',0,1,0,91),(288,12,'male',1,0,0,92),(295,6,'female',0,1,0,93),(295,6,'male',1,0,0,94),(295,12,'female',0,1,0,95),(295,12,'male',1,0,0,96),(184,6,'first eligibility option',0,0,0,97),(289,0,'first eligibility option',0,0,0,98),(295,5,'first eligibility option',0,0,0,99),(284,10,'first eligibility option',0,0,0,100),(284,11,'first eligibility option',0,0,0,101),(283,11,'first eligibility option',0,0,0,102),(286,11,'first eligibility option',0,0,0,103),(295,11,'first eligibility option',0,0,0,104),(287,11,'first eligibility option',0,0,0,105),(287,0,'first eligibility option',0,0,0,106),(289,-1,'first eligibility option',0,0,0,107),(289,11,'first eligibility option',0,0,0,108),(253,-1,'first eligibility option',0,0,0,109),(307,-1,'first eligibility option',0,0,0,110),(308,-1,'first eligibility option',0,0,0,111),(309,7,'first eligibility option',0,0,0,112),(309,0,'first eligibility option',0,0,0,113),(309,6,'female',0,1,0,114),(309,6,'male',1,0,1,115),(275,-1,'first eligibility option',0,0,0,117),(275,-1,'first eligibility option',0,0,0,118),(276,-1,'first eligibility option',0,0,0,119),(0,0,'first eligibility option',0,0,0,120),(0,12,'first eligibility option',0,0,0,121),(0,-1,'first eligibility option',0,0,0,122),(276,11,'first eligibility option',0,0,0,123),(309,11,'first eligibility option',0,0,0,125),(291,-1,'first eligibility option',0,0,0,131),(311,11,'first eligibility option',0,0,0,132),(327,-1,'first eligibility option',0,0,0,139),(328,-1,'first eligibility option',0,0,0,140),(309,-1,'first eligibility option',0,0,0,142),(295,-1,'first eligibility option',0,0,0,144),(288,-1,'first eligibility option',0,0,0,146),(327,2,'first eligibility option',0,0,0,147),(328,2,'first eligibility option',0,0,0,149),(329,2,'first eligibility option',0,0,0,150),(330,2,'first eligibility option',0,0,0,151),(325,2,'first eligibility option',0,0,0,152),(325,3,'first eligibility option',0,0,0,153),(329,0,'first eligibility option',0,0,0,154),(327,11,'first eligibility option',0,0,0,155),(328,11,'first eligibility option',0,0,0,156),(332,0,'first eligibility option',0,0,0,158),(332,7,'first eligibility option',0,0,0,169),(332,6,'Jestem hetero',0,1,0,170),(332,6,'Jestem gejem',1,0,1,171),(332,11,'first eligibility option',0,0,0,174),(384,6,'first eligibility option',0,0,0,15070),(385,2,'first eligibility option',0,0,0,71047),(385,3,'first eligibility option',0,0,0,72856),(336,2,'first eligibility option',0,0,0,74558);
/*!40000 ALTER TABLE `fdStepFormsEligibilityQuestionsOptions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-01 10:44:08
