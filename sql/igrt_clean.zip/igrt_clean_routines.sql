CREATE DATABASE  IF NOT EXISTS `igrt_clean` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `igrt_clean`;
-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: igrt_clean
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping routines for database 'igrt_clean'
--
/*!50003 DROP PROCEDURE IF EXISTS `cloneExperiment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`imgame`@`%` PROCEDURE `cloneExperiment`(IN ownerIdVal INT, IN srcExptId INT, IN newName TEXT, OUT outNewId INT)
BEGIN
	DECLARE oldId INT;
    DECLARE newId INT; 
	SET newId=-1;
	SELECT exptId INTO oldId FROM igExperiments WHERE title=newName; 
	IF (found_rows() = 0) THEN
		INSERT INTO igExperiments (title, ownerId) VALUES(newName, ownerIdVal);
		SELECT exptId INTO newId FROM igExperiments WHERE title=newName;

		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM edContentDefs_refactor WHERE exptId=srcExptId;
        ALTER TABLE tmp1 MODIFY id int null;
		UPDATE tmp1 SET id=null WHERE exptId=srcExptId;
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
		INSERT INTO edContentDefs_refactor SELECT * FROM tmp1 WHERE exptId=newId;

		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM edExptStatic_refactor WHERE exptId=srcExptId;
        ALTER TABLE tmp1 MODIFY id int null;
		UPDATE tmp1 SET id=null WHERE exptId=srcExptId;
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
		INSERT INTO edExptStatic_refactor SELECT * FROM tmp1 WHERE exptId=newId;

		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM edAlignmentControlLabels WHERE exptId=srcExptId;
			-- np PK 
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
		INSERT INTO edAlignmentControlLabels SELECT * FROM tmp1 WHERE exptId=newId;

		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM edSessions WHERE exptId=srcExptId;
        ALTER TABLE tmp1 MODIFY id int null;
		UPDATE tmp1 SET id=null WHERE exptId=srcExptId;
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
        UPDATE tmp1 SET step1Complete=0, step1EvenMarked=0, step1OddMarked=0 WHERE exptId=newId;
		INSERT INTO edSessions SELECT * FROM tmp1 WHERE exptId=newId;

		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM edLabels WHERE exptId=srcExptId;
        ALTER TABLE tmp1 MODIFY id int null;
		UPDATE tmp1 SET id=null WHERE exptId=srcExptId;
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
		INSERT INTO edLabels SELECT * FROM tmp1 WHERE exptId=newId;
        
        -- surveys/forms
 		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM fdStepForms WHERE exptId=srcExptId;
			-- no PK
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
		INSERT INTO fdStepForms SELECT * FROM tmp1 WHERE exptId=newId;
       
 		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM fdStepFormsEligibilityQuestions WHERE exptId=srcExptId;
			-- no PK
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
		INSERT INTO fdStepFormsEligibilityQuestions SELECT * FROM tmp1 WHERE exptId=newId;

		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM fdStepFormsEligibilityQuestionsOptions WHERE exptId=srcExptId;
			-- no PK
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
		INSERT INTO fdStepFormsEligibilityQuestionsOptions SELECT * FROM tmp1 WHERE exptId=newId;
        
		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM fdStepFormsGridValues WHERE exptId=srcExptId;
        ALTER TABLE tmp1 MODIFY id int null;
		UPDATE tmp1 SET id=null WHERE exptId=srcExptId;
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
		INSERT INTO fdStepFormsGridValues SELECT * FROM tmp1 WHERE exptId=newId;

		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM fdStepFormsPages WHERE exptId=srcExptId;
		-- No PK -- UPDATE tmp1 SET id=null WHERE exptId=srcExptId;
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
		INSERT INTO fdStepFormsPages SELECT * FROM tmp1 WHERE exptId=newId;

		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM fdStepFormsQuestions WHERE exptId=srcExptId;
		-- No PK -- UPDATE tmp1 SET id=null WHERE exptId=srcExptId;
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
		INSERT INTO fdStepFormsQuestions SELECT * FROM tmp1 WHERE exptId=newId;
        
		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM fdStepFormsQuestionsOptions WHERE exptId=srcExptId;
        ALTER TABLE tmp1 MODIFY id int null;
		UPDATE tmp1 SET id=null WHERE exptId=srcExptId;
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
		INSERT INTO fdStepFormsQuestionsOptions SELECT * FROM tmp1 WHERE exptId=newId;

		-- clean up
		DROP TABLE IF exists tmp1;
		SET outNewId = newId;
		-- SET tempId='xx';
		-- SET @newExptId = newId; 
	else
		SET outNewId = newId;
		-- SET tempId='zz';
		-- return -1 as error code so that user can be prompted to enter new unique name
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cloneForm` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `cloneForm`(IN targetExptId INT, IN targetFormType INT, IN sourceExptId INT, IN sourceFormType INT)
BEGIN
	-- get source data into working tables and set exptId and formType
	TRUNCATE TABLE wt_cloneForms;
	INSERT INTO wt_cloneForms SELECT * FROM fdStepForms WHERE exptId=sourceExptId AND formType=sourceFormType;
    UPDATE wt_cloneForms SET id=NULL;
	UPDATE wt_cloneForms SET exptId=targetExptId, formType=targetFormType;
	
	TRUNCATE TABLE wt_cloneFormsPages;
	INSERT INTO wt_cloneFormsPages SELECT * FROM fdStepFormsPages WHERE exptId=sourceExptId AND formType=sourceFormType;
    UPDATE wt_cloneFormsPages SET id=NULL;
	UPDATE wt_cloneFormsPages SET exptId=targetExptId, formType=targetFormType;

	TRUNCATE TABLE wt_cloneFormsQuestions;
	INSERT INTO wt_cloneFormsQuestions SELECT * FROM fdStepFormsQuestions WHERE exptId=sourceExptId AND formType=sourceFormType;
    UPDATE wt_cloneFormsQuestions SET id=NULL;
	UPDATE wt_cloneFormsQuestions SET exptId=targetExptId, formType=targetFormType;

	TRUNCATE TABLE wt_cloneFormsGridValues;
	INSERT INTO wt_cloneFormsGridValues SELECT * FROM fdStepFormsGridValues WHERE exptId=sourceExptId AND formType=sourceFormType;
    UPDATE wt_cloneFormsGridValues SET id=NULL;
	UPDATE wt_cloneFormsGridValues SET exptId=targetExptId, formType=targetFormType;

	TRUNCATE TABLE wt_cloneFormsQuestionsOptions;
	INSERT INTO wt_cloneFormsQuestionsOptions SELECT * FROM fdStepFormsQuestionsOptions WHERE exptId=sourceExptId AND formType=sourceFormType;
    UPDATE wt_cloneFormsQuestionsOptions SET id=NULL;
	UPDATE wt_cloneFormsQuestionsOptions SET exptId=targetExptId, formType=targetFormType;

	TRUNCATE TABLE wt_cloneFormsEligibilityQuestions;
	INSERT INTO wt_cloneFormsEligibilityQuestions SELECT * FROM fdStepFormsEligibilityQuestions WHERE exptId=sourceExptId AND formType=sourceFormType;
	UPDATE wt_cloneFormsEligibilityQuestions SET id=NULL;
	UPDATE wt_cloneFormsEligibilityQuestions SET exptId=targetExptId, formType=targetFormType;

	TRUNCATE TABLE wt_cloneFormsEligibilityQuestionsOptions;
	INSERT INTO wt_cloneFormsEligibilityQuestionsOptions SELECT * FROM fdStepFormsEligibilityQuestionsOptions WHERE exptId=sourceExptId AND formType=sourceFormType;
    UPDATE wt_cloneFormsEligibilityQuestionsOptions SET id=NULL;
	UPDATE wt_cloneFormsEligibilityQuestionsOptions SET exptId=targetExptId, formType=targetFormType;
    
	TRUNCATE TABLE wt_cloneFormsPageFilterQuestions;
	INSERT INTO wt_cloneFormsPageFilterQuestions SELECT * FROM fdStepFormsPageFilterQuestions WHERE exptId=sourceExptId AND formType=sourceFormType;
	UPDATE wt_cloneFormsPageFilterQuestions SET id=NULL;
	UPDATE wt_cloneFormsPageFilterQuestions SET exptId=targetExptId, formType=targetFormType;

	TRUNCATE TABLE wt_cloneFormsPageFilterQuestionsOptions;
	INSERT INTO wt_cloneFormsPageFilterQuestionsOptions SELECT * FROM fdStepFormsPageFilterQuestionsOptions WHERE exptId=sourceExptId AND formType=sourceFormType;
	UPDATE wt_cloneFormsPageFilterQuestionsOptions SET id=NULL;
	UPDATE wt_cloneFormsPageFilterQuestionsOptions SET exptId=targetExptId, formType=targetFormType;


	-- clear tables of this form/expt
	DELETE FROM fdStepForms WHERE exptId=targetExptId AND formType=targetFormType;
	DELETE FROM fdStepFormsPages WHERE exptId=targetExptId AND formType=targetFormType;
	DELETE FROM fdStepFormsQuestions WHERE exptId=targetExptId AND formType=targetFormType;
	DELETE FROM fdStepFormsQuestionsOptions WHERE exptId=targetExptId AND formType=targetFormType;
	DELETE FROM fdStepFormsEligibilityQuestions WHERE exptId=targetExptId AND formType=targetFormType;
	DELETE FROM fdStepFormsEligibilityQuestionsOptions WHERE exptId=targetExptId AND formType=targetFormType;
	DELETE FROM fdStepFormsPageFilterQuestions WHERE exptId=targetExptId AND formType=targetFormType;
	DELETE FROM fdStepFormsPageFilterQuestionsOptions WHERE exptId=targetExptId AND formType=targetFormType;
	DELETE FROM fdStepFormsGridValues WHERE exptId=targetExptId AND formType=targetFormType;
	-- reinsert from working tables
	INSERT INTO fdStepForms SELECT * FROM wt_cloneForms;
	INSERT INTO fdStepFormsPages SELECT * FROM wt_cloneFormsPages;
	INSERT INTO fdStepFormsGridValues SELECT * FROM wt_cloneFormsGridValues;
	INSERT INTO fdStepFormsQuestions SELECT * FROM wt_cloneFormsQuestions;
	INSERT INTO fdStepFormsQuestionsOptions SELECT * FROM wt_cloneFormsQuestionsOptions;
	INSERT INTO fdStepFormsEligibilityQuestions SELECT * FROM wt_cloneFormsEligibilityQuestions;
	INSERT INTO fdStepFormsEligibilityQuestionsOptions SELECT * FROM wt_cloneFormsEligibilityQuestionsOptions;
	INSERT INTO fdStepFormsPageFilterQuestions SELECT * FROM wt_cloneFormsPageFilterQuestions;
	INSERT INTO fdStepFormsPageFilterQuestionsOptions SELECT * FROM wt_cloneFormsPageFilterQuestionsOptions;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `deleteExperiment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteExperiment`(IN targetExptId INT, OUT delUC INT, OUT archRows INT)
BEGIN
	DECLARE deletedUserCnt INT;
	DECLARE archivedDataRows INT;
	DECLARE minUID INT;
	DECLARE maxUID INT;
	DECLARE oNo INT;
	DECLARE tempInt INT;
	-- get any values prior to deletion
	SELECT ownerId INTO oNo FROM igExperiments WHERE exptId=targetExptId; 

	DELETE FROM igExperiments WHERE exptId=targetExptId;
	DELETE FROM edContentDefs WHERE exptId=targetExptId;
	DELETE FROM edJudgeContent WHERE exptId=targetExptId;
	DELETE FROM edRespContent WHERE exptId=targetExptId;
	DELETE FROM edExptStatic WHERE exptId=targetExptId;
	DELETE FROM edLabels WHERE exptId=targetExptId;
	DELETE FROM edSessions WHERE exptId=targetExptId;
	DELETE FROM wt_Step2pptStatus WHERE exptId=targetExptId;
	DELETE FROM wt_Step1Allocations WHERE exptId=targetExptId;
	-- now delete and count # of system generated users.
	SET deletedUserCnt = 0;
	DROP TABLE IF exists sgUsers;
	CREATE TABLE sgUsers SELECT * FROM igActiveStep1Users WHERE exptId=targetExptId;
	IF (ROW_COUNT() > 0) THEN
		SELECT MAX(uid) INTO maxUID FROM sgUsers;
		SELECT MIN(uid) INTO minUID FROM sgUsers;
		DELETE FROM igUsers WHERE id>=minUID AND id<=maxUID;
		SET deletedUserCnt=deletedUserCnt + ROW_COUNT();
		DELETE FROM igActiveStep1Users WHERE exptId=targetExptId;
	END IF;
	DROP TABLE IF exists sgUsers;
	CREATE TABLE sgUsers SELECT * FROM igActiveClassicUsers WHERE exptId=targetExptId;
	IF (ROW_COUNT() > 0) THEN
		SELECT MAX(uid) INTO maxUID FROM sgUsers;
		SELECT MIN(uid) INTO minUID FROM sgUsers;
		DELETE FROM igUsers WHERE id>=minUID AND id<=maxUID;
		SET deletedUserCnt=deletedUserCnt + ROW_COUNT();
		DELETE FROM igActiveClassicUsers WHERE exptId=targetExptId;
	END IF;
	DROP TABLE IF exists sgUsers;
	-- now archive any data from this experiment
	SET archivedDataRows = 0;
	SET @archiveName=CONCAT('zz_',targetExptId,'_',oNo,'_arc');
	-- operate on tables
	SELECT exptId INTO tempInt FROM wt_Step4datasets WHERE exptId=targetExptId LIMIT 1;
	IF (ROW_COUNT() > 0) THEN
		SET @workingName=CONCAT(@archiveName, '_Step4datasets');
		SET @c = CONCAT('CREATE TABLE ', @workingName, ' SELECT * FROM wt_Step4datasets WHERE exptId=', targetExptId);
		PREPARE stmt from @c;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
		DELETE FROM wt_Step4datasets WHERE exptId=targetExptId;
		SET archivedDataRows = archivedDataRows + ROW_COUNT();
	END IF;
	SELECT exptId INTO tempInt FROM wt_Step3summaries WHERE exptId=targetExptId LIMIT 1;
	IF (ROW_COUNT() > 0) THEN
		SET @workingName=CONCAT(@archiveName, '_Step3summaries');
		SET @c = CONCAT('CREATE TABLE ', @workingName, ' SELECT * FROM wt_Step3summaries WHERE exptId=', targetExptId);
		PREPARE stmt from @c;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
		DELETE FROM wt_Step3summaries WHERE exptId=targetExptId;
		SET archivedDataRows = archivedDataRows + ROW_COUNT();
	END IF;

	SELECT exptId INTO tempInt FROM wt_Step2summaries WHERE exptId=targetExptId LIMIT 1;
	IF (ROW_COUNT() > 0) THEN
		SET @workingName=CONCAT(@archiveName, '_Step2summaries');
		SET @c = CONCAT('CREATE TABLE ', @workingName, ' SELECT * FROM wt_Step2summaries WHERE exptId=', targetExptId);
		PREPARE stmt from @c;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
		DELETE FROM wt_Step2summaries WHERE exptId=targetExptId;
		SET archivedDataRows = archivedDataRows + ROW_COUNT();
	END IF;

	SELECT exptId INTO tempInt FROM wt_Step4FormUIDs WHERE exptId=targetExptId LIMIT 1;
	IF (ROW_COUNT() > 0) THEN
		SET @workingName=CONCAT(@archiveName, '_Step4FormUIDs');
		SET @c = CONCAT('CREATE TABLE ', @workingName, ' SELECT * FROM wt_Step4FormUIDs WHERE exptId=', targetExptId);
		PREPARE stmt from @c;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
		DELETE FROM wt_Step4FormUIDs WHERE exptId=targetExptId;
		SET archivedDataRows = archivedDataRows + ROW_COUNT();
	END IF;

	SELECT exptId INTO tempInt FROM wt_Step2FormUIDs WHERE exptId=targetExptId LIMIT 1;
	IF (ROW_COUNT() > 0) THEN
		SET @workingName=CONCAT(@archiveName, '_Step2FormUIDs');
		SET @c = CONCAT('CREATE TABLE ', @workingName, ' SELECT * FROM wt_Step2FormUIDs WHERE exptId=', targetExptId);
		PREPARE stmt from @c;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
		DELETE FROM wt_Step2FormUIDs WHERE exptId=targetExptId;
		SET archivedDataRows = archivedDataRows + ROW_COUNT();
	END IF;

	SELECT exptId INTO tempInt FROM wt_Step1FormUIDs WHERE exptId=targetExptId LIMIT 1;
	IF (ROW_COUNT() > 0) THEN
		SET @workingName=CONCAT(@archiveName, '_Step1FormUIDs');
		SET @c = CONCAT('CREATE TABLE ', @workingName, ' SELECT * FROM wt_Step1FormUIDs WHERE exptId=', targetExptId);
		PREPARE stmt from @c;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
		DELETE FROM wt_Step1FormUIDs WHERE exptId=targetExptId;
		SET archivedDataRows = archivedDataRows + ROW_COUNT();
	END IF;

	SELECT exptId INTO tempInt FROM wt_Step1Discards WHERE exptId=targetExptId LIMIT 1;
	IF (ROW_COUNT() > 0) THEN
		SET @workingName=CONCAT(@archiveName, '_Step1Discards');
		SET @c = CONCAT('CREATE TABLE ', @workingName, ' SELECT * FROM wt_Step1Discards WHERE exptId=', targetExptId);
		PREPARE stmt from @c;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
		DELETE FROM wt_Step1Discards WHERE exptId=targetExptId;
		SET archivedDataRows = archivedDataRows + ROW_COUNT();
	END IF;

	SELECT exptId INTO tempInt FROM wt_Step2pptReviews WHERE exptId=targetExptId LIMIT 1;
	IF (ROW_COUNT() > 0) THEN
		SET @workingName=CONCAT(@archiveName, '_Step2pptReviews');
		SET @c = CONCAT('CREATE TABLE ', @workingName, ' SELECT * FROM wt_Step2pptReviews WHERE exptId=', targetExptId);
		PREPARE stmt from @c;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
		DELETE FROM wt_Step2pptReviews WHERE exptId=targetExptId;
		SET archivedDataRows = archivedDataRows + ROW_COUNT();
	END IF;
	SELECT exptId INTO tempInt FROM dataSTEP4 WHERE exptId=targetExptId LIMIT 1;
	IF (ROW_COUNT() > 0) THEN
		SET @workingName=CONCAT(@archiveName, '_step4');
		SET @c = CONCAT('CREATE TABLE ', @workingName, ' SELECT * FROM dataSTEP4 WHERE exptId=', targetExptId);
		PREPARE stmt from @c;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
		DELETE FROM dataSTEP4 WHERE exptId=targetExptId;
		SET archivedDataRows = archivedDataRows + ROW_COUNT();
	END IF;

	SELECT exptId INTO tempInt FROM md_dataStep2reviewed WHERE exptId=targetExptId LIMIT 1;
	IF (ROW_COUNT() > 0) THEN
		SET @workingName=CONCAT(@archiveName, '_step2Reviewed');
		SET @c = CONCAT('CREATE TABLE ', @workingName, ' SELECT * FROM md_dataStep2reviewed WHERE exptId=', targetExptId);
		PREPARE stmt from @c;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
		DELETE FROM md_dataStep2reviewed WHERE exptId=targetExptId;
		SET archivedDataRows = archivedDataRows + ROW_COUNT();
	END IF;

	SELECT exptId INTO tempInt FROM dataSTEP2 WHERE exptId=targetExptId LIMIT 1;
	IF (ROW_COUNT() > 0) THEN
		SET @workingName=CONCAT(@archiveName, '_step2');
		SET @c = CONCAT('CREATE TABLE ', @workingName, ' SELECT * FROM dataSTEP2 WHERE exptId=', targetExptId);
		PREPARE stmt from @c;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
		DELETE FROM dataSTEP2 WHERE exptId=targetExptId;
		SET archivedDataRows = archivedDataRows + ROW_COUNT();
	END IF;

	SELECT exptId INTO tempInt FROM dataSTEP1 WHERE exptId=targetExptId LIMIT 1;
	IF (ROW_COUNT() > 0) THEN
		SET @workingName=CONCAT(@archiveName,'_step1');
		SET @c = CONCAT('CREATE TABLE ', @workingName,' SELECT * FROM dataSTEP1 WHERE exptId=', targetExptId);
		PREPARE stmt from @c;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
		DELETE FROM dataSTEP1 WHERE exptId=targetExptId;
		SET archivedDataRows = archivedDataRows + ROW_COUNT();
	END IF;

	SELECT exptId INTO tempInt FROM dataClassic WHERE exptId=targetExptId LIMIT 1;
	IF (ROW_COUNT() > 0) THEN
		DEALLOCATE PREPARE stmt;
		SET @c = CONCAT('CREATE TABLE ', @workingName, ' SELECT * FROM dataClassic WHERE exptId=', targetExptId);
		PREPARE stmt from @c;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
		DELETE FROM dataClassic WHERE exptId=targetExptId;
		SET archivedDataRows = archivedDataRows + ROW_COUNT();
	END IF;

	SELECT exptId INTO tempInt FROM md_dataStep1reviewed WHERE exptId=targetExptId LIMIT 1;
	IF (ROW_COUNT() > 0) THEN
		SET @workingName=CONCAT(@archiveName, '_dataStep1reviewed');
		SET @c = CONCAT('CREATE TABLE ', @workingName, ' SELECT * FROM md_dataStep1reviewed WHERE exptId=', targetExptId);
		PREPARE stmt from @c;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
		DELETE FROM md_dataStep1reviewed WHERE exptId=targetExptId;
		SET archivedDataRows = archivedDataRows + ROW_COUNT();
	END IF;




	-- set OUT variables 
	SET delUC = deletedUserCnt;
	SET archRows = archivedDataRows;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getExperimentDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getExperimentDetails`(IN texptId INT, OUT etitle TEXT)
BEGIN
 	SET etitle = "no title defined";
	SELECT title INTO etitle FROM igExperiments WHERE exptId=texptId; 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getStep2Details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getStep2Details`(IN texptId INT, OUT dc INT, OUT sc INT)
BEGIN
 	SET dc = 0;
	SET sc = 0;
	SELECT COUNT(DISTINCT(dayNo)) INTO dc FROM dataSTEP2 WHERE exptId=texptId;
	SELECT COUNT(DISTINCT(sessionNo)) INTO sc FROM dataSTEP2 WHERE exptId=texptId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `populateContent` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `populateContent`(IN targetExptId INT)
BEGIN
    DECLARE langId INT;
	DECLARE judgeTab TEXT;
	DECLARE nonPTab TEXT;
	DECLARE testVal TEXT;
	DECLARE workingVal TEXT;
	SELECT languageId INTO langId FROM edContentDefs WHERE exptId=targetExptId; 
	IF (found_rows() != 0) THEN
		DROP TABLE IF exists srcJC;	
		DROP TABLE IF exists refJC;	
		DROP TABLE IF exists srcRC;	
		DROP TABLE IF exists refRC;
		DROP TABLE IF exists srcSC;	
		DROP TABLE IF exists refSC;

	
		CREATE TABLE srcJC SELECT * FROM edJudgeContent WHERE exptId=targetExptId;
		CREATE TABLE refJC SELECT * FROM edReferenceJudgeContent WHERE languageId=langId;
		CREATE TABLE srcRC SELECT * FROM edRespContent WHERE exptId=targetExptId;
		CREATE TABLE refRC SELECT * FROM edReferenceRespContent WHERE languageId=langId;
		-- if cols are empty in edJudgeContent then load from reference
		SELECT jTab INTO judgeTab FROM srcJC WHERE exptId=targetExptId;
		IF (judgeTab="") THEN
			DELETE FROM edJudgeContent WHERE exptId=targetExptId;
			UPDATE refJC SET exptId=targetExptId WHERE languageId=langId;
			INSERT INTO edJudgeContent SELECT * FROM refJC WHERE exptId=targetExptId;
		END IF;
		-- if cols are empty in edRespContent then load from reference
		SELECT npTab INTO nonPTab FROM srcRC WHERE exptId=targetExptId;
		IF (nonPTab="") THEN
			DELETE FROM edRespContent WHERE exptId=targetExptId;
			UPDATE refRC SET exptId=targetExptId WHERE languageId=langId;
			INSERT INTO edRespContent SELECT * FROM refRC WHERE exptId=targetExptId;
		END IF;
		-- clean update
		DROP TABLE IF exists srcJC;	
		DROP TABLE IF exists refJC;	
		DROP TABLE IF exists srcRC;	
		DROP TABLE IF exists refRC;	
		-- get individual static translations if necessary
		CREATE TABLE srcSC SELECT labelChoice,instLikert,labelReasons,labelFinalRating,labelChoiceFinalRating,labelReasonFinalRating,instFinalLikert FROM edExptStatic WHERE exptId=targetExptId;
		CREATE TABLE refSC SELECT * FROM edReferenceExptStatic WHERE languageId=langId;
		SELECT labelChoice INTO testVal FROM srcSC;
		IF (testVal = "") THEN
			SELECT labelChoice INTO workingVal FROM refSC WHERE languageId=langId;
			UPDATE edExptStatic SET labelChoice=workingVal WHERE exptId=targetExptId;
		END IF;
		SELECT instLikert INTO testVal FROM srcSC;
		IF (testVal = "") THEN
			SELECT instLikert INTO workingVal FROM refSC WHERE languageId=langId;
			UPDATE edExptStatic SET instLikert=workingVal WHERE exptId=targetExptId;
		END IF;
		SELECT labelReasons INTO testVal FROM srcSC;
		IF (testVal = "") THEN
			SELECT labelReasons INTO workingVal FROM refSC WHERE languageId=langId;
			UPDATE edExptStatic SET labelReasons=workingVal WHERE exptId=targetExptId;
		END IF;
		SELECT labelFinalRating INTO testVal FROM srcSC;
		IF (testVal = "") THEN
			SELECT labelFinalRating INTO workingVal FROM refSC WHERE languageId=langId;
			UPDATE edExptStatic SET labelFinalRating=workingVal WHERE exptId=targetExptId;
		END IF;
		SELECT labelChoiceFinalRating INTO testVal FROM srcSC;
		IF (testVal = "") THEN
			SELECT labelChoiceFinalRating INTO workingVal FROM refSC WHERE languageId=langId;
			UPDATE edExptStatic SET labelChoiceFinalRating=workingVal WHERE exptId=targetExptId;
		END IF;
		SELECT labelReasonFinalRating INTO testVal FROM srcSC;
		IF (testVal = "") THEN
			SELECT labelReasonFinalRating INTO workingVal FROM refSC WHERE languageId=langId;
			UPDATE edExptStatic SET labelReasonFinalRating=workingVal WHERE exptId=targetExptId;
		END IF;
		SELECT instFinalLikert INTO testVal FROM srcSC;
		IF (testVal = "") THEN
			SELECT instFinalLikert INTO workingVal FROM refSC WHERE languageId=langId;
			UPDATE edExptStatic SET instFinalLikert=workingVal WHERE exptId=targetExptId;
		END IF;
		DROP TABLE IF exists srcSC;	
		DROP TABLE IF exists refSC;
	END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `xinjectS1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `xinjectS1`(IN ownerIdVal INT, IN srcExptId INT, IN newName TEXT, OUT outNewId INT)
BEGIN
	DECLARE oldId INT;
    DECLARE newId INT; 
	SET newId=-1;
	SELECT exptId INTO oldId FROM igExperiments WHERE title=newName; 
	IF (found_rows() = 0) THEN
		INSERT INTO igExperiments (title, ownerId) VALUES(newName, ownerIdVal);
		SELECT exptId INTO newId FROM igExperiments WHERE title=newName;
		-- retrieve from and insert into edContentDefs and give new PK
		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM edContentDefs WHERE exptId=srcExptId;
		-- UPDATE tmp1 SET exptId=null WHERE exptId=srcExptId;
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
		INSERT INTO edContentDefs SELECT * FROM tmp1 WHERE exptId=newId;
		-- retrieve from and insert into edJudgeContent and give new link back to main PK
		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM edJudgeContent WHERE exptId=srcExptId;
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
		INSERT INTO edJudgeContent SELECT * FROM tmp1 WHERE exptId=newId;
		-- retrieve from and insert into edRespContent and give new link back to main PK
		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM edRespContent WHERE exptId=srcExptId;
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
		INSERT INTO edRespContent SELECT * FROM tmp1 WHERE exptId=newId;
		-- retrieve from and insert into edExptStatic and give new link back to main PK
		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM edExptStatic WHERE exptId=srcExptId;
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
		INSERT INTO edExptStatic SELECT * FROM tmp1 WHERE exptId=newId;
		-- retrieve from and insert into edLabels and give new link back to main PK
		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM edLabels WHERE exptId=srcExptId;
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
		INSERT INTO edLabels SELECT * FROM tmp1 WHERE exptId=newId;
		-- retrieve from and insert into edSessions and give new link back to main PK
		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM edSessions WHERE exptId=srcExptId;
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
		INSERT INTO edSessions SELECT * FROM tmp1 WHERE exptId=newId;
		-- retrieve from and insert into edLabels and give new link back to main PK
		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM edLabels WHERE exptId=srcExptId;
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
		INSERT INTO edLabels SELECT * FROM tmp1 WHERE exptId=newId;
		-- retrieve from and insert into md_dataStep1reviewed and give new link back to main PK
		DROP TABLE IF exists tmp1;	
		CREATE TABLE tmp1 SELECT * FROM md_dataStep1reviewed WHERE exptId=srcExptId;
		UPDATE tmp1 SET exptId=newId WHERE exptId=srcExptId;
		INSERT INTO md_dataStep1reviewed SELECT * FROM tmp1 WHERE exptId=newId;
		-- clean up
		DROP TABLE IF exists tmp1;
		SET outNewId = newId;
		-- SET tempId='xx';
		-- SET @newExptId = newId; 
	else
		SET outNewId = newId;
		-- SET tempId='zz';
		-- return -1 as error code so that user can be prompted to enter new unique name
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `xinjectS1S2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `xinjectS1S2`(IN srcExptId INT, IN newExptId INT)
BEGIN
-- 	DECLARE oldId INT;
--  DECLARE newId INT; 
-- 	SET newId=-1;
	TRUNCATE wt_x_Step2pptReviews;
    TRUNCATE wt_x_injectStep2reviewed;
    TRUNCATE wt_x_injectStep1reviewed;

    INSERT INTO wt_x_Step2pptReviews SELECT * FROM wt_Step2pptReviews WHERE exptId = srcExptId;
    UPDATE wt_x_Step2pptReviews SET exptId=newExptId, id=NULL;
    INSERT INTO wt_Step2pptReviews SELECT * FROM wt_x_Step2pptReviews WHERE exptId = newExptId;

    INSERT INTO wt_x_injectStep2reviewed SELECT * FROM md_dataStep2reviewed WHERE exptId = srcExptId;
    UPDATE wt_x_injectStep2reviewed SET exptId=newExptId, id=NULL;
    INSERT INTO md_dataStep2reviewed SELECT * FROM wt_x_injectStep2reviewed WHERE exptId= srcExptId;

    INSERT INTO wt_x_injectStep1reviewed SELECT * FROM md_dataStep1reviewed WHERE exptId = srcExptId;
    UPDATE wt_x_injectStep1reviewed SET exptId=newExptId;
    INSERT INTO md_dataStep1reviewed SELECT * FROM wt_x_injectStep1reviewed WHERE exptId = srcExptId;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-01 10:48:32
