-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: igrt_clean
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edReferenceJudgeContent`
--

DROP TABLE IF EXISTS `edReferenceJudgeContent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `edReferenceJudgeContent` (
  `exptId` int NOT NULL COMMENT 'placeholder for when this row gets imporetd to new experiment',
  `languageId` int NOT NULL COMMENT 'l',
  `jTab` text CHARACTER SET utf8mb3 NOT NULL,
  `jTabUnconnected` text CHARACTER SET utf8mb3 NOT NULL,
  `jTabWaiting` text CHARACTER SET utf8mb3 NOT NULL,
  `jTabActive` text CHARACTER SET utf8mb3 NOT NULL,
  `jTabRating` text CHARACTER SET utf8mb3 NOT NULL,
  `jTabDone` text CHARACTER SET utf8mb3 NOT NULL,
  `jWaitingToStart` text CHARACTER SET utf8mb3 NOT NULL,
  `jPleaseAsk` text CHARACTER SET utf8mb3 NOT NULL,
  `jAskButton` text CHARACTER SET utf8mb3 NOT NULL,
  `jWaitingForReplies` text CHARACTER SET utf8mb3 NOT NULL,
  `jHistoryTitle` text CHARACTER SET utf8mb3 NOT NULL,
  `jRatingTitle` text CHARACTER SET utf8mb3 NOT NULL,
  `jFinalRatingTitle` text CHARACTER SET utf8mb3 NOT NULL,
  `jRatingYourQuestion` text CHARACTER SET utf8mb3 NOT NULL,
  `jRatingQ` text CHARACTER SET utf8mb3 NOT NULL,
  `jRatingR1` text CHARACTER SET utf8mb3 NOT NULL,
  `jRatingR2` text CHARACTER SET utf8mb3 NOT NULL,
  `jAskAnotherB` text CHARACTER SET utf8mb3 NOT NULL,
  `jNoMoreB` text CHARACTER SET utf8mb3 NOT NULL,
  `jSaveFinalB` text CHARACTER SET utf8mb3 NOT NULL,
  `jFinalMsg` text CHARACTER SET utf8mb3 NOT NULL,
  `jConfirmHead` text CHARACTER SET utf8mb3 NOT NULL,
  `jConfirmBody` text CHARACTER SET utf8mb3 NOT NULL,
  `jConfirmOK` text CHARACTER SET utf8mb3 NOT NULL,
  `jConfirmCancel` text CHARACTER SET utf8mb3 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edReferenceJudgeContent`
--

LOCK TABLES `edReferenceJudgeContent` WRITE;
/*!40000 ALTER TABLE `edReferenceJudgeContent` DISABLE KEYS */;
INSERT INTO `edReferenceJudgeContent` VALUES (0,15,'Judge','unconnected','waiting','active','judging','complete','Waiting for the experiment to start','Please ask a question','Send question','Please wait for replies','Previous questions/answers','Please make some ratings','Please make some final judgements.','Please ask a question','','Response 1:','Response 2:','Ask another question','No more questions','Save my final ratings','Thank you for being a judge. Please continue to answer questions to other judges as appropriate.','','','',''),(0,18,'Tuomari','Ei yhteydessÃ¤','Odottaa','Aktiivinen','Arviointi','Valmis','Odotetaan kokeen alkua','Kysy kysymys','LÃ¤hetÃ¤ kysymys','Ole hyvÃ¤ ja odota vastauksia','Aiemmat kysymykset/vastaukset','Ole hyvÃ¤ ja tee arviot','Ole hyvÃ¤ ja tee lopulliset arviot','Kysy kysymys','Kysymys','Vastaus 1:','Vastaus 2: ','Kysy seuraava kysymys','Ei enempÃ¤Ã¤ kysymyksiÃ¤','Tallenna lopulliset arvioni','Kiitos tuomarin roolissa toimimisesta. Ole hyvÃ¤ ja vastaa vielÃ¤ muiden tuomareiden esittÃ¤miin kysymyksiin tarkoituksenmukaisella tavalla. ','Oletko varma?','Oletko varma, ettet halua kysyÃ¤ enempÃ¤Ã¤   kysymyksiÃ¤? Sinut ohjataan seuraavaksi tekemÃ¤Ã¤n lopullinen arvio. ','viimeistely','peruuttaa'),(0,14,'Jurylid','Niet verbonden','Wachten','Actief','Beoordelen','Compleet','Wacht tot het experiment start','Stel een vraag','Verstuur vraag','Wacht op de antwoorden','Vorige vragen/antwoorden','Geef alsjeblieft een score','Geef alsjeblieft een eindoordeel','Stel een vraag','Vraag:','Antwoord 1:','Antwoord 2:','Stel een nieuwe vraag','Geen vragen meer','Sla mijn beoordelingen op','Bedankt voor het vervullen van je rol als jurylid. Blijf alsjeblieft antwoord geven op de vragen van de andere juryleden.','Weet je het zeker?','Weet je zeker dat je geen vragen meer wil stellen? Je wordt hierna gevraagd om een eindoordeel te geven.','afmaken','annuleren'),(0,57,'Juez','desconectado','en espera ','activo','juzgando','finalizado ','Esperando a que comience el experimento ','Haz una pregunta','EnvÃ­a tu pregunta','Espera respuesta','Preguntas/respuestas anteriores','Haz tu valoraciÃ³n','Expresa tu opiniÃ³n final','Haz una pregunta','Pregunta','Respuesta 1:','Respuesta 2:','Haz otra pregunta','No hagas mÃ¡s preguntas','Guardar mi valoraciÃ³n final','Gracias por ser Juez. ContinÃºa respondiendo a las preguntas de los otros jueces.','Â¿EstÃ¡s seguro?','Â¿EstÃ¡s seguro de que has terminado de hacer preguntas? A continuaciÃ³n tendrÃ¡s que hacer tu valoraciÃ³n.','Terminar','Cancelar'),(0,47,'SÄ™dzia','niepoÅ‚Ä…czony','czekaj','aktywne','ocenianie','uzupeÅ‚nione','Czekaj na rozpoczÄ™cie eksperymetnu','ProszÄ™ zadaÄ‡ pytanie','WyÅ›lij pytanie','Czekaj na odpowiedzi','Poprzednie pytania/odpowiedzi','ProszÄ™ dokonaÄ‡ oceny','ProszÄ™ dokonaÄ‡ ostatecznego wyboru','ProszÄ™ zadaÄ‡ pytanie','Pytanie','OdpowiedÅº 1:','OdpowiedÅº 2:','Zadaj nastÄ™pne pytanie','Nie mam wiÄ™cej pytaÅ„','Zapisz moje koÅ„cowe oceny','DziÄ™kujemy za bycie sÄ™dziÄ…. Prosimy kontynuowaÄ‡ odpowiadanie na pytania innych sÄ™dziÃ³w.','JesteÅ› pewny?','JesteÅ› pewny, Å¼e nie chcesz zadaÄ‡ wiÄ™cej pytaÅ„? Zostaniesz poproszony o podanie koÅ„cowej oceny.','ZakoÅ„cz','Anuluj');
/*!40000 ALTER TABLE `edReferenceJudgeContent` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-10 16:30:09
