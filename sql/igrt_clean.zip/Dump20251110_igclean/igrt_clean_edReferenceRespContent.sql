-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: igrt_clean
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edReferenceRespContent`
--

DROP TABLE IF EXISTS `edReferenceRespContent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `edReferenceRespContent` (
  `exptId` int NOT NULL COMMENT 'placeholder only - populated when used in clone/copy experiments',
  `languageId` int NOT NULL,
  `npTab` text CHARACTER SET utf8mb3 NOT NULL,
  `pTab` text CHARACTER SET utf8mb3 NOT NULL,
  `rTabInactive` text CHARACTER SET utf8mb3 NOT NULL,
  `rTabActive` text CHARACTER SET utf8mb3 NOT NULL,
  `rTabWaiting` text CHARACTER SET utf8mb3 NOT NULL,
  `rTabDone` text CHARACTER SET utf8mb3 NOT NULL,
  `rWaitFirst` text CHARACTER SET utf8mb3 NOT NULL,
  `rWaitNext` text CHARACTER SET utf8mb3 NOT NULL,
  `rHistoryTitle` text CHARACTER SET utf8mb3 NOT NULL,
  `rCurrentQ` text CHARACTER SET utf8mb3 NOT NULL,
  `rInstruction` text CHARACTER SET utf8mb3 NOT NULL,
  `rSendB` text CHARACTER SET utf8mb3 NOT NULL,
  `rGuidanceHeader` text CHARACTER SET utf8mb3 NOT NULL,
  `rYourAnswer` text CHARACTER SET utf8mb3 NOT NULL,
  `rFinalMsg` text CHARACTER SET utf8mb3 NOT NULL,
  `npGuidance` text CHARACTER SET utf8mb3 NOT NULL,
  `pGuidance` text CHARACTER SET utf8mb3 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edReferenceRespContent`
--

LOCK TABLES `edReferenceRespContent` WRITE;
/*!40000 ALTER TABLE `edReferenceRespContent` DISABLE KEYS */;
INSERT INTO `edReferenceRespContent` VALUES (0,15,'Non-pretender','Pretender','inactive','active','waiting','complete','Please wait for the first question','Please wait for the next question','Previous questions/answers','Current question:','Please enter your answer and then click on \"[button content injected here\".','Send answer','Guidance notes','Your answer:','The judge has finished asking you questions. Thank you.','',''),(0,18,'Ei-teeskentelijÃ¤','TeeskentelijÃ¤','Toimeton','Aktiivinen','waiting','Valmis','Ole hyvÃ¤ ja odota ensimmÃ¤istÃ¤ kysymystÃ¤','Ole hyvÃ¤ ja odota seuraavaa kysymystÃ¤','Aiemmat kysymykset/vastaukset','Kysymys tÃ¤llÃ¤ hetkellÃ¤:','Ole hyvÃ¤ ja kirjoita vastauksesi. Klikkaa sitten â€˜lÃ¤hetÃ¤ vastausâ€™ ','LÃ¤hetÃ¤ vastaus','Ohjeet','Vastauksesi:','Tuomari on nyt kysynyt kaikki kysymykset.','',''),(0,14,'Oprechte deelnemer ','Niet oprechte deelnemer ','Inactief','Actief ','Wachten','Compleet','Wacht a.u.b. op de eerste vraag','Wacht a.u.b. op de volgende vraag','Vorige vragen/antwoorden','Huidige vraag:','Geef a.u.b. uw antwoord en klik dan op â€™verstuur antwoordâ€™ ','Verstuur antwoord','Handleiding ','Jouw antwoord:','Het jurylid is klaar met het stellen van vragen. Geef a.u.b. je antwoord en klik dan op â€˜verstuur antwoordâ€™ ','NP','P'),(0,57,'No fingidor','Fingidor','Inactivo','Activo','waiting','Finalizado','Espera la primera pregunta','Espera la siguiente pregunta','Preguntas/respuestas anteriores','Pregunta actual:','Escribe tu respuesta y haz clic en â€envÃ­a tu respuestaâ€','EnvÃ­a tu respuesta','GuÃ­a orientativa','Tu respuesta','El Juez ha terminado con sus preguntas. Escribe tu respuesta y haz clic en â€envÃ­a tu respuestaâ€','NP','P'),(0,47,'Osoba nieudajÄ…ca','Osoba udajÄ…ca','nieaktywne','aktywne','waiting','uzupeÅ‚nione','ProszÄ™ czekaÄ‡ na pierwsze pytanie','ProszÄ™ czekaÄ‡ na nastÄ™pne pytanie','Poprzednie pytania/odpowiedzi','Obecne pytanie','ProszÄ™ wpisaÄ‡ odpowiedÅº i kliknÄ…Ä‡ â€žwyÅ›lij odpowiedÅºâ€','WyÅ›lij odpowiedÅº','WskazÃ³wki','Twoja odpowiedÅº','SÄ™dzia skoÅ„czyÅ‚ zadawaÄ‡ pytania. ','NP','P');
/*!40000 ALTER TABLE `edReferenceRespContent` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-10 16:26:25
