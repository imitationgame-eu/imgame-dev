-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: igrt_clean
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edExptStatic_refactor`
--

DROP TABLE IF EXISTS `edExptStatic_refactor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `edExptStatic_refactor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `exptId` int NOT NULL COMMENT 'placeholder only',
  `language` int NOT NULL,
  `owner` int NOT NULL,
  `isClassic` tinyint NOT NULL DEFAULT '0',
  `useAutoLogins` tinyint NOT NULL DEFAULT '0',
  `s1usersSet` int NOT NULL DEFAULT '0',
  `exptSubject` int NOT NULL DEFAULT '1',
  `location` int NOT NULL,
  `country` int NOT NULL DEFAULT '225',
  `noJudges` int NOT NULL DEFAULT '12',
  `extraJ` tinyint NOT NULL DEFAULT '0',
  `extraNP` tinyint NOT NULL DEFAULT '0',
  `extraP` tinyint NOT NULL DEFAULT '0',
  `canClone` tinyint NOT NULL DEFAULT '1',
  `useRating` tinyint NOT NULL DEFAULT '1',
  `useLikert` tinyint NOT NULL DEFAULT '1',
  `noLikert` int NOT NULL DEFAULT '5',
  `useReasons` tinyint NOT NULL DEFAULT '1',
  `useFinalRating` tinyint NOT NULL DEFAULT '1',
  `useReasonFinalRating` int NOT NULL DEFAULT '1',
  `noDays` int NOT NULL DEFAULT '1',
  `noSessions` int NOT NULL DEFAULT '1',
  `useFinalLikert` tinyint NOT NULL DEFAULT '0',
  `noFinalLikert` tinyint NOT NULL DEFAULT '5',
  `step1RecruitForm` tinyint NOT NULL DEFAULT '0',
  `step1ConsentForm` tinyint NOT NULL DEFAULT '0',
  `step1PreForm` tinyint NOT NULL DEFAULT '0',
  `step1PostForm` int NOT NULL DEFAULT '0',
  `step2Sequential` int NOT NULL DEFAULT '0',
  `step2RecruitForm` int NOT NULL DEFAULT '0',
  `step2ConsentForm` int NOT NULL DEFAULT '0',
  `step2PreForm` int NOT NULL DEFAULT '0',
  `step2PostForm` int NOT NULL DEFAULT '0',
  `step4Sequential` int NOT NULL DEFAULT '1',
  `step4RecruitForm` int NOT NULL DEFAULT '0',
  `step4ConsentForm` int NOT NULL DEFAULT '0',
  `step4PreForm` int NOT NULL DEFAULT '0',
  `step4PostForm` int NOT NULL DEFAULT '0',
  `step2PreInvert` int NOT NULL DEFAULT '0',
  `step2PostInvert` int NOT NULL DEFAULT '0',
  `useReasonCharacterLimit` int NOT NULL DEFAULT '0',
  `reasonCharacterLimitValue` int NOT NULL DEFAULT '1',
  `useReasonCharacterLimitF` int NOT NULL DEFAULT '0',
  `reasonCharacterLimitValueF` int NOT NULL DEFAULT '0',
  `useS1Intention` int NOT NULL DEFAULT '0',
  `useS1IntentionMin` int NOT NULL DEFAULT '0',
  `s1IntentionMin` int NOT NULL DEFAULT '5',
  `useS1AlignmentControl` int NOT NULL DEFAULT '0',
  `useS1QCategoryControl` int NOT NULL DEFAULT '0',
  `s1NoCategories` int NOT NULL DEFAULT '0',
  `useS4Intention` int NOT NULL DEFAULT '0' COMMENT 'implies single presentation of each turn, but can be forced with useS4IndividualTurn',
  `useS4IntentionMin` int NOT NULL DEFAULT '0',
  `s4IntentionMin` int NOT NULL DEFAULT '100',
  `useS4IndividualTurn` int NOT NULL DEFAULT '0',
  `s4RandomiseSide` int NOT NULL DEFAULT '0' COMMENT 'only used if useS4Intention OR useS4IndividualTurn are set',
  `useS4AlignmentControl` int NOT NULL DEFAULT '0',
  `useS4QCategoryControl` int NOT NULL DEFAULT '0',
  `s4NoCategories` int NOT NULL DEFAULT '0',
  `useS2PAlignment` int NOT NULL DEFAULT '0',
  `useIS2NPAlignment` int NOT NULL DEFAULT '0',
  `s1barbilliardControl` int NOT NULL DEFAULT '1' COMMENT 'if set, the step1 admin screen controls when the final rating is allowed. If not, the ''n more questions'' alternative appears after a fixed number of questions.',
  `s1QuestionCountAlternative` int NOT NULL DEFAULT '3' COMMENT 'No of step1 questions before ''no more Q'' button visible (if not using s1barbilliardControl)',
  `randomiseSideS1` int NOT NULL DEFAULT '1',
  `useStep2ReplyCalculation` int NOT NULL DEFAULT '0',
  `useOddInvertedS2` int NOT NULL DEFAULT '0',
  `useEvenInvertedS2` int NOT NULL DEFAULT '0',
  `useS2CharacterLimit` int NOT NULL DEFAULT '0',
  `s2CharacterLimitValue` int NOT NULL DEFAULT '1',
  `useIS2CharacterLimit` int NOT NULL DEFAULT '0',
  `iS2CharacterLimitValue` int NOT NULL DEFAULT '1',
  `useStep4ReasonCharacterLimit` int NOT NULL DEFAULT '1',
  `s4_reasonCharacterLimitValue` int NOT NULL DEFAULT '1',
  `useS4CharacterLimit` int NOT NULL DEFAULT '0',
  `s4CharacterLimitValue` int NOT NULL DEFAULT '1',
  `choosingNP` int NOT NULL DEFAULT '0',
  `hasSpecials` int NOT NULL DEFAULT '0',
  `specialSnowShuffle` int NOT NULL DEFAULT '0',
  `appendITypetoS1AlignmentNoneLabel` int NOT NULL DEFAULT '0',
  `appendITypetoS1AlignmentPartlyLabel` int NOT NULL DEFAULT '0',
  `appendITypetoS1AlignmentMostlyLabel` int NOT NULL DEFAULT '0',
  `appendITypetoS1AlignmentCompletelyLabel` int NOT NULL DEFAULT '0',
  `appendITypetoS1AlignmentExtraLabel` int NOT NULL DEFAULT '0',
  `s1feedbackTime` int NOT NULL DEFAULT '2000',
  `s1giveFeedback` int NOT NULL DEFAULT '0',
  `s1runningScore` int NOT NULL DEFAULT '0',
  `s1giveFeedbackFinal` int NOT NULL DEFAULT '0',
  `useS1AlignmentNoneLabel` int NOT NULL DEFAULT '0',
  `useS1AlignmentPartlyLabel` int NOT NULL DEFAULT '0',
  `useS1AlignmentMostlyLabel` int NOT NULL DEFAULT '0',
  `useS1AlignmentCompletelyLabel` int NOT NULL DEFAULT '0',
  `useS1AlignmentExtraLabel` int NOT NULL DEFAULT '0',
  `useS1AlignmentAsRB` int NOT NULL DEFAULT '0',
  `s1PercentForWinFeedbackFinal` int NOT NULL DEFAULT '50',
  `useS1MinQuestionLimit` int NOT NULL DEFAULT '0',
  `s1MinQuestionLimit` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edExptStatic_refactor`
--

LOCK TABLES `edExptStatic_refactor` WRITE;
/*!40000 ALTER TABLE `edExptStatic_refactor` DISABLE KEYS */;
INSERT INTO `edExptStatic_refactor` VALUES (132,1,15,28,0,1,1,9,6,225,24,0,0,0,1,1,1,4,1,1,1,2,2,1,4,0,0,0,0,1,0,0,1,1,1,0,0,0,0,0,0,0,2,0,64,1,1,0,1,1,3,1,1,4,1,1,1,1,1,1,1,1,3,1,0,0,0,0,0,0,0,1,1,1,256,1,0,0,0,0,0,0,0,2000,0,0,0,1,1,1,1,0,0,50,0,0);
/*!40000 ALTER TABLE `edExptStatic_refactor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-10 16:27:44
