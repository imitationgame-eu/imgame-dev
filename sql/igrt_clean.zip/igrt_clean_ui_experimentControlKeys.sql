CREATE DATABASE  IF NOT EXISTS `igrt_clean` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `igrt_clean`;
-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: igrt_clean
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ui_experimentControlKeys`
--

DROP TABLE IF EXISTS `ui_experimentControlKeys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ui_experimentControlKeys` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(128) CHARACTER SET latin1 DEFAULT NULL,
  `controlName` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
  `experimentControlHeaderKey` int DEFAULT NULL,
  `isSubsection` int DEFAULT NULL,
  `pageLabel` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
  `sectionNo` int DEFAULT NULL,
  `contingentControl` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ui_experimentControlKeys`
--

LOCK TABLES `ui_experimentControlKeys` WRITE;
/*!40000 ALTER TABLE `ui_experimentControlKeys` DISABLE KEYS */;
INSERT INTO `ui_experimentControlKeys` VALUES (1,'Experiment description','experimentDescription',1,1,'1_2_1',0,0),(2,'Experiment status (pre-flight check)','experimentPFC',1,0,'1_2_2',-1,0),(3,'Step1 sessions and users','s1sessions',2,1,'1_2_1',1,0),(4,'Step1 interrogator rating options','s1iRating',2,1,'1_2_1',2,0),(5,'Step1 interrogator final-rating options','s1ifRating',2,1,'1_2_1',3,0),(6,'Step1 interrogator alignment options','s1iAlignment',2,1,'1_2_1',4,0),(7,'Step1 interrogator content','s1iContent',2,1,'1_2_1',5,0),(8,'Step1 respondent content','s1rContent',2,1,'1_2_1',6,0),(9,'Step2 pretender content','s2pContent',3,1,'1_2_1',7,0),(10,'Step2 pretender reply and alignment options','s2pAlignment',3,1,'1_2_1',8,0),(11,'Step2 balancer','s2Balancer',3,1,'1_2_1',9,0),(12,'Inverted step2 non-pretender content','is2npContent',4,1,'1_2_1',10,0),(13,'Inverted step2 non-pretender reply and alignm','is2npAlignment',4,1,'1_2_1',11,0),(14,'Inverted step2 balancer','is2Balancer',4,1,'1_2_1',12,0),(15,'Step4 judge content','s4jContent',5,1,'1_2_1',13,0),(16,'Step4 judge alignment options','s4jAlignment',5,1,'1_2_1',14,0),(17,'Configure surveys','surveysConfigure',6,1,'1_2_1',15,0),(18,'Review surveys','surveysReview',6,1,'1_2_1',16,0),(19,'Step1 runtime controller','s1Runtime',7,1,'4_2_0',255,0),(20,'Step1 monitor','s1Monitor',7,1,'4_2_1',255,0),(21,'Review step1 data','s1Review',7,1,'1_2_1',17,0),(22,'Monitor P step2','s2pMonitor',8,1,'1_2_1',18,0),(23,'Review P step2','s2pReview',8,1,'1_2_1',19,0),(24,'Monitor NP (inverted) step2','s2npMonitor',8,1,'1_2_1',20,1),(25,'Review NP (inverted) step2','s2npReview',8,1,'1_2_1',21,1),(26,'Select shuffle datasource (P/NP)','s3dataSource',9,1,'1_2_1',22,1),(27,'Create shuffle','s3Shuffle',9,1,'1_2_1',23,0),(28,'Create snow shuffle (null experiment)','s3snowShuffle',9,1,'1_2_1',24,1),(29,'Step4 monitor','s4Monitor',10,1,'1_2_1',25,0),(30,'Step1 dialogues','s1Dialogues',11,1,'1_2_1',26,0),(31,'Step2 P answer sets','s2pAnswers',11,1,'1_2_1',27,0),(32,'Step2 NP (inverted) answer sets ','s2npAnswers',11,1,'1_2_1',28,0),(33,'Audit report','auditReport',11,1,'1_2_1',29,0),(34,'Step4 quantitative question sets (csv)','quantQSets',11,1,'1_2_1',30,0),(35,'Step4 qualitative grouped sets (rtf grouped by S2)','qualQSets',11,1,'1_2_1',31,0),(43,'Null experiment monitor','neMonitor',10,1,'1_2_1',32,0),(44,'Null exp quantitative questions sets (csv)','neQuantQSets',11,1,'1_2_1',33,0),(45,'Null exp qualitative grouped sets (rtf grouped by S2)','neQualQSets',11,1,'1_2_1',34,0),(46,'Linked experiment shuffle','leShuffle',9,1,'1_2_1',35,0),(47,'Linked experiment monitor','leMonitor',10,1,'1_2_1',36,0),(48,'Reflexive (tbt) experiment shuffle','tbtShuffle',9,1,'1_2_1',37,0),(49,'Reflexive (tbt) experiment monitor','tbtMonitor',10,1,'1_2_1',38,0),(50,'Classic Step1 dialogues','classicStep1Dialogues',11,1,'1_2_1',39,0);
/*!40000 ALTER TABLE `ui_experimentControlKeys` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-01 10:48:22
